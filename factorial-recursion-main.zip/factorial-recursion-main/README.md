Hey everyone this side Rudransh Goswmai & today 
I've try to build the solid idea for factorial & recurisons...

Here u got the core idea and one example of factorials and recurisons 


Note : This project was build for educational & skill testing purpose only , 
it dosen't make harm to any private/govt firm.

Created & directed by 
Rudransh Goswami
your freind :)
